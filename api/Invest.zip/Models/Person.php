<?php
class Person
{
    public $id;
    public $name;
    public $surname;
    public $email;
    public $cell;
    public $bankname;
    public $accountType;
    public $branch;
    public $status;
}
?>