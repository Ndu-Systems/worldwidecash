﻿app.controller("HomeCtrl", function () {
   
})