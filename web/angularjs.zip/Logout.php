<?php
require 'head.php';
require 'nav.php';
?>
	<!--//Header-->
	<!--/inner_banner-->
	<div class="inner_banner">
	</div>
	<!--//inner_banner-->
	<!--/short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

		
		</div>
	</div>
	<!--//short-->
	<!-- /inner_content -->
	<div class="banner_bottom">
		<div class="container" ng-controller="logoutController">
			
</div>
			</div>
		<div class="message">	{{message}} </div>
				
			</div>
		</div>
	</div>
<?php
require 'footer.php';
?>