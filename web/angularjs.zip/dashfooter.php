	<!--footer -->
	<div class="footer2">

		
	</div>
