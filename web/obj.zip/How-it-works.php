<?php
require 'head.php';
require 'nav.php';
?>
		<!--//top-bar-w3-agile-->
	</div>
	<!--/inner_banner-->
	<div class="inner_banner">
	</div>
	<!--//inner_banner-->
	<!--/short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

			
		</div>
	</div>
	<!--//short-->
	<!-- /inner_content -->
	<!-- /about -->
	<div class="banner_bottom">
		<div class="container">
			<h3 class="tittle">How it works?</h3>

			<div class="inner_sec_info_wthree_agile">
				
				<div class="news-main">
					<div class="col-md-10">
				<h4  class="tittle">Our Mission</h4> <br>

<p>There are thousands and thousands of people in South North West and East of Africa who lives under poor conditions. 
Our mission is to register all these individuals let them participate in our community so that we can better represent their needs</p><br>

<h4  class="tittle">Our Vision</h4><br>

 <p>To create an environment where all members can can freely participate without fear. We aim to create economic opportunity for all groups of people around the globe </p><br><br>

 <a href="images/table.PNG" target="_blank"><img src="images/table.PNG" style="width:100%"></a>
					</div>
					<div class="col-md-10">
						
						
<br><br>
<h4>For daily updates follow us on  : 					<a class="facebook" href="https://www.facebook.com/" target="_blank"><span  style="color:blue">Facebook</a></a></h4>

						<p>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
require 'footer.php';
?>