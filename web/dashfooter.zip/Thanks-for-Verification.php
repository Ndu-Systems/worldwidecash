<?php
require 'head.php';
?>
		<!--//top-bar-w3-agile-->
	</div>
	
	<!--//inner_banner-->
	<!--/short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

			
		</div>
	</div>
	<!--//short-->
	<!-- /inner_content -->
	<!-- /about -->
	<div class="banner_bottom">
		<div class="container">
			<h3 class="tittle">Thanks for verifying the payment</h3>

			<div class="inner_sec_info_wthree_agile">
				<div class="ab_info">

	<a href="Dashboard"><input type="button" value="GO TO MY DASHBOARD" class="myInput" style="background:#2ecc71; color:white; border: none"/></a>


				<h4></h4>
						<p class="sub_p"> 
						</p>
				</div>

				
			</div>
		</div>
	</div>
