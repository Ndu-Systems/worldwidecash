<?php
require 'head.php';
require 'nav.php';
?>
		<!--//top-bar-w3-agile-->
	</div>
	<!--/inner_banner-->
	<div class="inner_banner">
	</div>
	<!--//inner_banner-->
	<!--/short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

			
		</div>
	</div>
	<!--//short-->
	<!-- /inner_content -->
	<!-- /about -->
	<div class="banner_bottom">
		<div class="container">
			<h3 class="tittle">How it works?</h3>

			<div class="inner_sec_info_wthree_agile">
				
				<div class="news-main">
					<div class="col-md-10">
					
					</div>
					<div class="col-md-10">
						
						
<br><br>
<h4>For daily updates follow us on  : 					<a class="facebook" href="https://www.facebook.com/" target="_blank"><span  style="color:blue">Facebook</a></a></h4>

						<p>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
require 'footer.php';
?>