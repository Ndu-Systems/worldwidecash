<body>
	<!--Header-->
	<div class="header" id="home">
		<!--top-bar-w3-agile-->
		<div class="top-bar_w3agileits">
			<div class="top-logo_info_w3layouts">
				<div class="col-md-3 logo">
					<h1><a class="navbar-brand" href="Home">Funders<font color="green">Life</font></a></h1>
				</div>
				<div class="col-md-9 adrress_top">
					<div class="adrees_info">
						<div class="col-md-6 visit">
							
							
							<div class="clearfix"></div>
						</div>
						<div class="col-md-6 mail-us">
							<div class="col-md-2 col-sm-2 col-xs-2 contact-icon">
								<span class="fa fa-envelope" aria-hidden="true"></span>
							</div>
							<div class="col-md-10 col-sm-10 col-xs-10 contact-text">
								<h4>Mail us</h4>
								<p><a href="mailto:info@worldwidecash.com">info@funderslife.com</a></p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="header-nav">
				
			</div>
		</div>
		
