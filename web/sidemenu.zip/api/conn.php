<?php
  //$conn = new PDO('mysql:host=127.0.0.1;dbname=quunivn_worldwidecash','quunivn_main','Harder01!');
 $conn = new PDO('mysql:host=localhost;dbname=worldwidecash','root','');
?>