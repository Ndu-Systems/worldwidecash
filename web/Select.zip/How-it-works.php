<?php
require 'head.php';
require 'nav.php';
?>
		<!--//top-bar-w3-agile-->
	</div>
	<!--/inner_banner-->
	<div class="inner_banner">
	</div>
	<!--//inner_banner-->
	<!--/short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

			
		</div>
	</div>
	<!--//short-->
	<!-- /inner_content -->
	<!-- /about -->
	<div class="banner_bottom">
		<div class="container">
			<h3 class="tittle">How it works?</h3>

			<div class="inner_sec_info_wthree_agile">
				
				<div class="news-main">
					<div class="col-md-10">
				

<p>
80% compounded interest in 30 days.!
Once you successfully sign up, you will have to donate/PH 
the sum of either R200 R1000, R2000, R5000 to the maximum of 50000 as per table to a member that will be automatically assigned to you by the sytem. After which you are to upload your proof of payment immediately. Note that once you are matched to make a donation,you have a maximum of 72HOURS to complete all transactions, also if a beneficiary
 fails to confirm a donor after 72hrs of payment,you have to inform support
 Ensure you have a valid email address,an active phone number and a functional
 bank account before you sign up.
</p><br>
<b>The table bellow with monthly growth</b>
 <a href="images/table.PNG" target="_blank"><img src="images/table.PNG" style="width:100%"></a>
					</div>
					<div class="col-md-10">
						
						
<br><br>
<h4>For daily updates follow us on  : 					<a class="facebook" href="https://www.facebook.com/" target="_blank"><span  style="color:blue">Facebook</a></a></h4>

						<p>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
require 'footer.php';
?>