<?php
require 'head.php';
require 'nav.php';
?>
	<!--//Header-->
	<!--/inner_banner-->
	<div class="inner_banner">
	</div>
	<!--//inner_banner-->
	<!--/short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

			
		</div>
	</div>
	<!--//short-->
	<!-- /inner_content -->
	<div class="banner_bottom">
		<div class="container"   ng-controller="joinController">
			<div class="tittle_head">
				<h3 class="tittle">Sign up for free</h3>
			</div>
			<div class="inner_sec_info_wthree_agile">
				<div class="form">
				
				<div class="row">
  <div class="col-sm-6">
  	<label>Your Name</label><br>
	<input type="text" class="myInput" ng-model="name"/>
  </div>
  <div class="col-sm-6">
  <label>Your Surname</label><br>
	<input type="text" class="myInput" ng-model="surname"/>
  </div>
  <div class="col-sm-12">
   <label>Your Email</label><br>
	<input type="email" class="myInput" ng-model="email"/>
  </div>
  <div class="col-sm-12">
   <label>Choose Password</label><br>
	<input type="password" class="myInput" ng-model="password"/>
  </div>
  <div class="col-sm-12">
   <label>Confirm Password</label><br>
	<input type="password" class="myInput" ng-model="passwordConfirm"/>
  </div>
   <div class="col-sm-12">
    <label></label><br>
	<input type="button" value="GET STARTED" class="myInput" ng-click="Join()" style="background:#2ecc71; color:white; border: none"/>
  </div>
  <div class="col-sm-12">
    <label></label><br>
<h4 class="message">  {{message}}<h4>
  </div>
</div>
				
				
				
				</div>
			</div>
			
				
			</div>
		</div>
	</div>
<?php
require 'footer.php';
?>