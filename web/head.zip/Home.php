<?php
require 'head.php';
require 'nav.php';
?>
		<!--//top-bar-w3-agile-->
		<!-- banner-text -->
		<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider4">
					<li>
						<div class="banner-top">
							<div class="banner-info_agileits_w3ls">
								<h3>Earn 80% Interest Per month and live your dream.</h3>
								
							</div>

						</div>
					</li>
					<li>
						<div class="banner-top1">
							<div class="banner-info_agileits_w3ls">
							<h3>See your everyday growth.</h3>
								</div>

						</div>
					</li>
					<li>
						<div class="banner-top2">
							<div class="banner-info_agileits_w3ls">
							<h3>Get support every day</h3>
								</div>

						</div>
					</li>
					<li>
						<div class="banner-top3">
							<div class="banner-info_agileits_w3ls">
							<h3>Investment Solutions</h3></div>

						</div>
					</li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<!--//Slider-->
	</div>
	<!-- /about -->
	<div class="banner_bottom">
		<div class="container">
			<div class="news-main">
				<div class="col-md-6 news-left">
					<div class="col-md-6 b_left">
						<img src="images/ab.jpg" alt=" " class="img-responsive">

					</div>
					<div class="col-md-6 b_right">

					</div>
				</div>
				<div class="col-md-6 news-right">
					<h4>About Us</h4>
					
					<p>
					This is a community of ordinary people, selflessly helping each other, a kind of the Global Fund of mutual aid. This is the first sprout of something new in modern soulless and ruthless world of greed and hard cash. The goal here is not the money. The goal is to destroy the world's unjust financial system.
					</p>
					
						<h4  class="tittle">Our Mission</h4> <br>

<p>There are thousands and thousands of people in South North West and East of Africa who lives under poor conditions. 
Our mission is to register all these individuals let them participate in our community so that we can better represent their needs</p><br>

<h4  class="tittle">Our Vision</h4><br>

 <p>To create an environment where all members can can freely participate without fear. We aim to create economic opportunity for all groups of people around the globe </p><br><br>

				</div>
			</div>
		</div>
	</div>
	

	<?php
require 'footer.php';
?>
